const chatbox = document.getElementById("chatbox");
const input = document.getElementById("input");

input.addEventListener("keypress", async (e) => {
  if (e.key === "Enter") {
    const message = input.value.trim();
    if (!message) return;
    addMessage("You", message);
    input.value = "";

    // Call your backend API
    const reply = await getAIResponse(message);
    addMessage("AI", reply);
  }
});

function addMessage(sender, message) {
  chatbox.innerHTML += `<p><strong>${sender}:</strong> ${message}</p>`;
  chatbox.scrollTop = chatbox.scrollHeight;
}

async function getAIResponse(msg) {
  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg })
    });
    const data = await res.json();
    return data.reply;
  } catch (err) {
    return "Error contacting AI service.";
  }
}