const express = require('express');
const { Configuration, OpenAIApi } = require('openai');
const app = express();
const path = require('path');

require('dotenv').config();

app.use(express.static(path.join(__dirname)));
app.use(express.json());

const openai = new OpenAIApi(new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
}));

app.post('/chat', async (req, res) => {
  const userInput = req.body.message;
  try {
    const response = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: userInput }],
    });
    const reply = response.data.choices[0].message.content;
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.json({ reply: "Sorry, something went wrong." });
  }
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
